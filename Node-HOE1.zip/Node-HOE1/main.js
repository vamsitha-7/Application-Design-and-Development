//Name: Vamsitha Gude


function sayHi() {
    console.log("Hi");
}
sayHi();

let aModule = require("./myModule");

console.log(aModule());

let otherModule = require("./myOtherModule");

console.log(otherModule.sayHello("Vamsitha"));
console.log(otherModule.myAdd(12, 56));

let addThis = require("./myOtherModule").myAdd(78, 34);
console.log(addThis);

let fs = require("fs");
fs.writeFile("myFile.txt", "Hey there", () => { console.log("file written") });

let aJoke = require("one-liner-joke");

let randomJoke = aJoke.getRandomJoke();
console.log(randomJoke);