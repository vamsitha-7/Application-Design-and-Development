//Name: Vamsitha Gude


function sayHello() {
    return "Hello";
}

module.exports = sayHello;