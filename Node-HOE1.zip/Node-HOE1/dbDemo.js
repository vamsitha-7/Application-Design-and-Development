//Name: Vamsitha Gude


'use strict'
const sql = require('mssql');

const config = {
    user: 'csu',
    password: 'rams',
    server: 'buscissql1901\\cisweb',
    database: 'RWStudiosAPI',
    trustServerCertificate: true
}

sql.connect(config)
    .then(myConnection => {
        return myConnection.query('Select * from film')

    })
    .then(myResult => {
        console.log(myResult.recordset)
    })
    .catch(myError => { console.log("Something went wrong", myError) });