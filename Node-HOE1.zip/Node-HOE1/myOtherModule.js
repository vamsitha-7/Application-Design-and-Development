//Name: Vamsitha Gude


function sayHello(aName) {
    return `Hello ${aName}`;
}

function addTwoNumbers(num1, num2) {
    return num1 + num2;
}

module.exports = { sayHello: sayHello, myAdd: addTwoNumbers };